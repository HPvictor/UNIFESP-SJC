from enum import Enum


class Priority(Enum):
    HIGH = 0
    MEDIUM = 1
    LOW = 2

class DuplicateItemError(Exception):
    pass
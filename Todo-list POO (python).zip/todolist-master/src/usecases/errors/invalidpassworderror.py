class InvalidPasswordError(Exception):
  pass
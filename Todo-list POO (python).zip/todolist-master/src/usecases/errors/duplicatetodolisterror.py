class DuplicateTodoListError(Exception):
    pass
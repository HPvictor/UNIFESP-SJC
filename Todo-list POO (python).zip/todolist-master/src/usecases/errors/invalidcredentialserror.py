class InvalidCredentialsError(Exception):
  pass
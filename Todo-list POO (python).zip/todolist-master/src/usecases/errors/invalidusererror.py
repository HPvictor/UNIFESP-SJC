class InvalidUserError(Exception):
    pass
class DuplicateUserError(Exception):
    pass